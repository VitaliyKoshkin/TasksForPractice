﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AcronymExpansion
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ButtonSendMessage_Click(object sender, EventArgs e)
        {
            //We create 3 vars
            char Symbols;
            string UserInputText = TextBox.Text;
            string Abbreviation = "";
            RedoneMessage.Text = "";
            //making a function for checking each symbol written in the TextBox one by one
            for (int i = 0; i<TextBox.Text.Length; i++)
            {
                //Add each symbol into Abbreviation. When it has 2 symbols, we are checking, if it is an abbreviation or not.
                Symbols = UserInputText[i];
                Abbreviation = Abbreviation + Symbols;
                //The problem with checking next symbol of abbreviation. Need checking
                if ((Abbreviation.Length == 2) && (Symbols != ' '))
                {
                    switch (Abbreviation)
                    {
                        case "gg":
                            RedoneMessage.Text = RedoneMessage.Text + "Good game";
                            Abbreviation = "";
                            break;
                        case "dw":
                            RedoneMessage.Text = RedoneMessage.Text + "Don't worry";
                            Abbreviation = "";
                            break;
                        case "hf":
                            RedoneMessage.Text = RedoneMessage.Text + "Have fun";
                            Abbreviation = "";
                            break;
                        case "wp":
                            RedoneMessage.Text = RedoneMessage.Text + "Well played";
                            Abbreviation = "";
                            break;
                        case "gl":
                            RedoneMessage.Text = RedoneMessage.Text + "Good luck";
                            Abbreviation = "";
                            break;
                            //A problem is in default case:
                        default:
                            RedoneMessage.Text = TextBox.Text;
                            break;
                    }
                }
                //if length is more than 2, we need to check for 3 letters' abbreviations.
                else if(Abbreviation.Length > 2)
                {
                    switch (Abbreviation)
                    {
                        case "lol":
                            RedoneMessage.Text = RedoneMessage.Text + "Laugh out loud";
                            Abbreviation = "";
                            break;
                        case "brb":
                            RedoneMessage.Text = RedoneMessage.Text + "Be right back";
                            Abbreviation = "";
                            break;
                        case "g2g":
                            RedoneMessage.Text = RedoneMessage.Text + "got to go";
                            Abbreviation = "";
                            break;
                        case "imo":
                            RedoneMessage.Text = RedoneMessage.Text + "In my opinion";
                            Abbreviation = "";
                            break;
                        default:
                            RedoneMessage.Text = TextBox.Text;
                            break;
                        /*One main problem: 1)I need to have a better checking(it's not working correctly in several situations). 
                         If you give me some advice about the ideas and improving my code, I'll be very glad to listen.*/
                    }
                }
            }
        }
    }
}

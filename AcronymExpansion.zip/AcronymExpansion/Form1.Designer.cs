﻿namespace AcronymExpansion
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.RedoneMessage = new System.Windows.Forms.Label();
            this.TextBox = new System.Windows.Forms.TextBox();
            this.ButtonSendMessage = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // RedoneMessage
            // 
            this.RedoneMessage.AutoSize = true;
            this.RedoneMessage.Location = new System.Drawing.Point(47, 117);
            this.RedoneMessage.Name = "RedoneMessage";
            this.RedoneMessage.Size = new System.Drawing.Size(0, 13);
            this.RedoneMessage.TabIndex = 0;
            // 
            // TextBox
            // 
            this.TextBox.Location = new System.Drawing.Point(12, 53);
            this.TextBox.Name = "TextBox";
            this.TextBox.Size = new System.Drawing.Size(137, 20);
            this.TextBox.TabIndex = 1;
            // 
            // ButtonSendMessage
            // 
            this.ButtonSendMessage.Location = new System.Drawing.Point(167, 53);
            this.ButtonSendMessage.Name = "ButtonSendMessage";
            this.ButtonSendMessage.Size = new System.Drawing.Size(75, 23);
            this.ButtonSendMessage.TabIndex = 2;
            this.ButtonSendMessage.Text = "Send";
            this.ButtonSendMessage.UseVisualStyleBackColor = true;
            this.ButtonSendMessage.Click += new System.EventHandler(this.ButtonSendMessage_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.ButtonSendMessage);
            this.Controls.Add(this.TextBox);
            this.Controls.Add(this.RedoneMessage);
            this.Name = "Form1";
            this.Text = "Chat";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label RedoneMessage;
        private System.Windows.Forms.TextBox TextBox;
        private System.Windows.Forms.Button ButtonSendMessage;
    }
}

